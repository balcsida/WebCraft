<?php include('header.php') ?>
				<h1 class="title">Welcome!</h1>
				<p>
					This is a Minecraft inspired web template, built with modern technologies (HTML5, CSS3).<br>
					It's working on all major browsers and on mobile devices too!
				</p>
				<p class="text-center">
					<img src="img/mockup.png" width="600" height="355">
				</p>
				<p>
					It has extremely optimized code, that GTMetrix gives double A for the speed (anyway, this also depends on the server configuration).<br>
				</p>
				<p class="text-center">
					<img src="img/gtmetrix.png" width="653" height="77">
				</p>
<?php include('footer.php') ?>